package com.advance.splitmethod;

public class SplitMethod {
public static void main(String[] args) {
			
		String txt= (" 22  +  45  -  (  343  /  1256 ) ");
		String[] w=txt.split("________");
		
		for(String w1:w){  
			System.out.println(w1); 
			//System.out.println(" ");
		}
	}

	}