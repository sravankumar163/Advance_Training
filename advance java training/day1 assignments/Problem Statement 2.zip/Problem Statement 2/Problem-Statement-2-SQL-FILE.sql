Create database ShoppingCart ;
use ShoppingCart ;

CREATE TABLE `shoppingcart`.`books` ( `Book_Id` INT NULL, `Book_Name` VARCHAR(45) NULL, `Aurthor` VARCHAR(45) NULL, `Price` INT NOT NULL, PRIMARY KEY (`Book_Id`));
  
select * from  shoppingcart.books ;

CREATE TABLE `shoppingcart`.`order_details` ( `Order_Id` INT NOT NULL, `Book_Id` INT NOT NULL, `Cust_Name` VARCHAR(45) NULL,
  `Phone_No` INT NOT NULL, `Address` VARCHAR(45) NULL, `Order_Date` INT NOT NULL, `Quantity` INT NOT NULL, PRIMARY KEY (`Order_Id`));

select * from  shoppingcart.order_details;

CREATE TABLE `shoppingcart`.`users` ( `first_name` VARCHAR(45) NULL, `address` VARCHAR(45) NULL, `email` VARCHAR(45) NULL,
  `user_name` INT NULL, `password` VARCHAR(45) NULL,  `registration_date` INT NULL);
  
  select * from  shoppingcart.users;